module.exports = {
  arrowParens: 'avoid',
  bracketSpacing: false,
  jsxSingleQuote: false,
  jsxBracketSameLine: false,
  semi: true,
  singleQuote: true,
  tabWidth: 2,
  trailingComma: 'all',
};
