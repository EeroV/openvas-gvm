#!/bin/bash

exec gosu ospd-openvas "$@"
