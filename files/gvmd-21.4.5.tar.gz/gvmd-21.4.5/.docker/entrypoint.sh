#!/bin/bash

exec gosu gvmd "$@"
